=== Custom Search by BestWebSoft ===
Contributors: bestwebsoft
Donate link: http://bestwebsoft.com/donate/
Tags: additional search options, extra search options, advanced search, add additional search options, search options, custom search, custom search plugin, website search, add custom posts to search, custom posts, free additional search options, custom content types
Requires at least: 3.8
Tested up to: 4.7.1
Stable tag: 1.35
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add custom post types and taxonomies to WordPress website search results.

== Description ==

Custom Search plugin adds custom post types and taxonomies to WordPress website search results. A quick and easy way to search everything within custom post types and taxonomies.
Improve your website user experience today!

http://www.youtube.com/watch?v=qF2-pFM_ESw

= Free Features =

* Search by:
	* All custom post types including:
		* [Galleries](http://bestwebsoft.com/products/wordpress/plugins/gallery/?k=a7970636432b7a4dcc5ad805f87b2696)
		* [Portfolio projects](http://bestwebsoft.com/products/wordpress/plugins/portfolio/?k=2ac66bf272f5329cdf78ed8cb10d49b2)
		* [Cars](http://bestwebsoft.com/products/wordpress/plugins/car-rental/?k=4f3314a1fe385c140e4ff9e361b2e300)
		* [Properties & Agents](http://bestwebsoft.com/products/wordpress/plugins/realty/?k=9916846ebbdecc2ba40ce3bff4fbf9f2)
		* [Jobs](http://bestwebsoft.com/products/wordpress/plugins/job-board/)
	* Taxonomies: [NEW]
		* Post tags
		* Post categories
		* Custom
* Compatible with latest WordPress version
* Incredibly simple settings for fast setup without modifying code
* Detailed step-by-step documentations and videos
* Multilingual and RTL ready

> **Pro Features**
>
> All features from Free version included plus:
>
> * Exclude from a custom search:
> 	* Posts
> 	* Pages
> * Configure custom post types and taxonomies displaying order on the search results page
> * Display featured image for post types on the search results page
> * Choose featured image size
> * Choose featured image align position:
> 	* Left
> 	* Right
> * Search by the post type of the current page
> * Change excerpt length
> * Add custom code via plugin settings page
> * Get answer to your question within one business day ([Support Policy](http://bestwebsoft.com/support-policy/))
>
> [Upgrade to Pro Now](http://bestwebsoft.com/products/wordpress/plugins/custom-search/?k=b67e3e538cdb8bb841b81467655eb0f7)

If you have a feature suggestion or idea you'd like to see in the plugin, we'd love to hear about it! [Suggest a Feature](http://support.bestwebsoft.com/hc/en-us/requests/new)

= Documentation & Videos =

* [[Doc] Installation](https://docs.google.com/document/d/1fPZmLyDQxMe0wxaKN-Mbi6Aa9R8vbL6dG365oXVVeSU/)
* [[Doc] Purchase, Installation & Configuration](https://docs.google.com/document/d/1fudtNHNgqHq8_YZ02TtsAwoiLyMnZ-hbiWwBCMAfcTc/)
* [[Video] Installation Instruction](https://www.youtube.com/watch?v=2tuQNyfXZ-I)
* [[Video] Purchase, Installation, Configuration Tutorial](https://www.youtube.com/watch?v=6w7qOA9P0HY)

= Help & Support =

Visit our Help Center if you have any questions, our friendly Support Team is happy to help - <http://support.bestwebsoft.com/>

= Translation =

* Czech (cs_CZ) (thanks to [PaMaDeSSoft](mailto:info@pamadessoft.cz), www.pamadessoft.cz)
* Russian (ru_RU)
* Spanish (es_ES) (thanks to [Fernando De León](mailto:mrjosefernando@gmail.com))
* Ukrainian (uk)

Some of these translations are not complete. We are constantly adding new features which should be translated. If you would like to create your own language pack or update the existing one, you can send [the text of PO and MO files](http://codex.wordpress.org/Translating_WordPress) to [BestWebSoft](http://support.bestwebsoft.com/hc/en-us/requests/new) and we'll add it to the plugin. You can download the latest version of the program for work with PO and MO [files Poedit](http://www.poedit.net/download.php).

= Recommended Plugins =

* [Custom Fields Search](http://bestwebsoft.com/products/wordpress/plugins/custom-fields-search/) - Add custom fields to WordPress website search results.
* [Updater](http://bestwebsoft.com/products/wordpress/plugins/updater/?k=7b42404bbc8ad8cb8745f8704cba3c9a) - Automatically check and update WordPress core with all installed plugins to the latest versions. Manual mode, email notifications and backups of all your files and database before updating.

= Donate =

Donations play an important role in supporting open-source projects. We greatly appreciate any donation you can make to help us continue further development of free products.

[Donate Now](http://bestwebsoft.com/donate/)

== Installation ==

1. Upload the folder `custom-search-plugin` to the directory `/wp-content/plugins/`.
2. Activate the plugin via the 'Plugins' menu in WordPress.
3. Plugin settings are available in "BWS Panel"->"Custom Search".

[View a Step-by-step Instruction on Custom Search Installation](https://docs.google.com/document/d/1fPZmLyDQxMe0wxaKN-Mbi6Aa9R8vbL6dG365oXVVeSU/)

== Frequently Asked Questions ==

= Usage =

Go to the Settings page and select custom post types and taxonomies that you would like to add to the search.

= I have some problems with the plugin's work. What Information should I provide to receive proper support? =

Please make sure that the problem hasn't been discussed yet on our forum (<http://support.bestwebsoft.com>). If no, please provide the following data along with your problem's description:

1. the link to the page where the problem occurs
2. the name of the plugin and its version. If you are using a pro version - your order number.
3. the version of your WordPress installation
4. copy and paste into the message your system status report. Please read more here: [Instruction on System Status](https://docs.google.com/document/d/1Wi2X8RdRGXk9kMszQy1xItJrpN0ncXgioH935MaBKtc/edit)

== Screenshots ==

1. Custom Search Settings page.
2. Custom Search Appearance page.

== Changelog ==

= V1.35 - 12.01.2017 =
* NEW : Ability to search by term name has been added.

= V1.34 - 09.08.2016 =
* Update : All functionality for wordpress 4.6 was updated.

= V1.33 - 27.06.2016 =
* Update : BWS panel section is updated.

= V1.32 - 15.03.2016 =
* NEW : The Czech language file is added.

= V1.31 - 30.11.2015 =
* Bugfix : The bug with plugin menu duplicating was fixed.

= V1.30 - 25.09.2015 =
* Update : We updated all functionality for wordpress 4.3.1.

= V1.29 - 06.07.2015 =
* New : Ability to restore settings to defaults.
* Update : BWS plugins section is updated.

= V1.28 - 05.06.2015 =
* Update : BWS plugins section is updated.
* Update : The Ukrainian and Russian languages are updated in the plugin.

= V1.27 - 15.05.2015 =
* NEW : We added checkbox to mark all custom post types in the settings page.
* Update : BWS plugins section is updated.
* Update : We updated all functionality for wordpress 4.2.2.

= V1.26 - 06.03.2015 =
* Bugfix : Bugs with syntax error and undefined function were fixed.

= V1.25 - 05.03.2015 =
* Update : BWS plugins section is updated.

= V1.24 - 05.03.2015 =
* Bugfix : Script file linking was fixed.
* Bugfix : We added search variable checking to make sure it is not empty in order to avoid conflicts.
* Update : We updated all functionality for wordpress 4.1.1.

= V1.23 - 26.12.2014 =
* Update : BWS plugins section is updated.
* Update : We updated all functionality for wordpress 4.1.

= V1.22 - 12.08.2014 =
* Update : We updated all functionality for wordpress 4.0-beta3.
* Bugfix : Security Exploit was fixed.

= V1.21 - 23.05.2014 =
* Update : We updated all functionality for wordpress 3.9.1.
* Update : The Ukrainian language is updated in the plugin.

= V1.20 - 08.04.2014 =
* Update : BWS plugins section is updated.
* Update : We updated all functionality for wordpress 3.8.1.
* Bugfix : Plugin optimization is done.
* Bugfix : Problem with including nav_menu types to the search results is fixed.
* Bugfix : Bug with displaying of custom types of deactiveted plugins is fixed.

= V1.19 - 07.02.2014 =
* Update : Screenshots are updated.
* Update : BWS plugins section is updated.
* Update : We updated all functionality for wordpress 3.8.1.
* Budfix : Problem with search results in back-end is fixed.

= V1.18 - 26.12.2013 =
* Update : BWS plugins section is updated.
* Update : We updated all functionality for wordpress 3.8.

= V1.17 - 25.11.2013 =
* Update : BWS plugins section is updated.
* Bugfix : The error with argument 2 in function array_merge() is fixed.

= V1.16 - 31.10.2013 =
* Update : We updated all functionality for wordpress 3.7.1.
* Update : Activation of radio button or checkbox by clicking on its label.
* NEW : Add checking installed wordpress version.

= V1.15 - 02.10.2013 =
* Update : We updated all functionality for wordpress 3.6.1.
* NEW : The Ukrainian language file is added to the plugin.

= V1.14 - 04.09.2013 =
* Update : We updated all functionality for wordpress 3.6.
* Update : Function for displaying BWS plugins section placed in a separate file and has own language files.
* NEW : Added additional links on the plugin page.

= V1.13 - 18.07.2013 =
* NEW : Added an ability to view and send system information by mail.
* Update : We updated all functionality for wordpress 3.5.2.

= V1.12 - 24.05.2013 =
* Bugfix : The error related to undefined variable is fixed.
* Changed : BWS plugins section.

= V1.11 - 06.05.2013 =
* Update : The Spanish language is updated in the plugin.

= V1.10 - 17.04.2013 =
* Update : The English language is updated in the plugin.

= V1.09 - 20.02.2013 =
* NEW : The Spanish language file is added to the plugin.

= V1.08 - 31.01.2013 =
* Bugfix : The admin menu bug is fixed.
* Update : We updated all functionality for wordpress 3.5.1.

= V1.07 - 21.12.2012 =
* Update : We updated all functionality for wordpress 3.5.

= V1.06 - 24.07.2012 =
* Bugfix : Cross Site Request Forgery bug is fixed.

= V1.05 - 10.07.2012 =
* NEW : The Hebrew language file is added to the plugin.
* Update : We updated all functionality for wordpress 3.4.1.

= V1.04 - 27.06.2012 =
* Update : We updated all functionality for wordpress 3.4.

= V1.03 - 12.03.2012 =
* Changed : BWS plugins section.

= V1.02 - 24.02.2012 =
* Change : Code which includes styles and scripts is added to the plugin for correct SSL verification.

= V1.01 - 21.02.2012 =
* NEW : Language files are added to the plugin.

== Upgrade Notice ==

= V1.35 =
* New features added.

= V1.34 =
* The compatibility with new WordPress version updated.

= V1.33 =
BWS panel section is updated.

= V1.32 =
The Czech language file is added.

= V1.31 =
The bug with plugin menu duplicating was fixed.

= V1.30 =
We updated all functionality for wordpress 4.3.1.

= V1.29 =
Ability to restore settings to defaults.

= V1.28 =
BWS plugins section is updated. The Ukrainian and Russian languages are updated in the plugin.

= V1.27 =
We added checkbox to mark all custom post types in the settings page. BWS plugins section is updated. We updated all functionality for wordpress 4.2.2.

= V1.26 =
Bugs with syntax error and undefined function were fixed.

= V1.25 =
BWS plugins section is updated.

= V1.24 =
Script file linking was fixed. We added search variable checking to make sure it is not empty in order to avoid conflicts. We updated all functionality for wordpress 4.1.1.

= V1.23 =
BWS plugins section is updated. We updated all functionality for wordpress 4.1.

= V1.22 =
Security Exploit was fixed. We updated all functionality for wordpress 4.0-beta3.

= V1.21 =
We updated all functionality for wordpress 3.9.1. The Ukrainian language is updated in the plugin.

= V1.20 =
BWS plugins section is updated. We updated all functionality for wordpress 3.8.1. Plugin optimization is done. Problem with including nav_menu types to the search results is fixed. Bug with displaying of custom types of deactiveted plugins is fixed.

= V1.19 =
Screenshots are updated. BWS plugins section is updated. We updated all functionality for wordpress 3.8.1. Problem with search results in back-end is fixed.

= V1.18 =
BWS plugins section is updated. We updated all functionality for wordpress 3.8.

= V1.17 =
BWS plugins section is updated. The error with argument 2 in function array_merge() is fixed.

= V1.16 =
We updated all functionality for wordpress 3.7.1. Activation of radio button or checkbox by clicking on its label. Add checking installed wordpress version.

= V1.15 =
We updated all functionality for wordpress 3.6.1. The Ukrainian language file is added to the plugin.

= V1.14 =
We updated all functionality for wordpress 3.6. Function for displaying BWS plugins section placed in a separate file and has own language files. Added additional links on the plugin page.

= V1.13 =
Added an ability to view and send system information by mail. We updated all functionality for wordpress 3.5.2.

= V1.12 =
The error related to undefined variable is fixed. BWS plugins section.

= V1.11 =
The Spanish language is updated in the plugin.

= V1.10 =
The English language is updated in the plugin.

= V1.09 =
The Spanish language file is added to the plugin.

= V1.08 =
Bugs in admin menu were fixed. We updated all functionality for wordpress 3.5.1.

= V1.07 =
We updated all functionality for wordpress 3.5.

= V1.06 =
Cross Site Request Forgery bug was fixed.

= V1.05 =
The Hebrew language file is added to the plugin. We updated all functionality for wordpress 3.4.1.

= V1.04 =
We updated all functionality for wordpress 3.4.

= V1.03 =
BWS plugins section has been changed.

= V1.02 =
Code which includes styles and scripts is added to the plugin for correct SSL verification.

= V1.01 =
Language files are added to the plugin.
